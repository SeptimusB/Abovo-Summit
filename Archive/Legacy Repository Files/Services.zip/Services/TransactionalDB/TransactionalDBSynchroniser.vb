﻿Imports Abovo.FileManager
Namespace Abovo

    Public Class TransactionalDBSynchroniser

        Private ModelID As Integer
        Private WB As DevExpress.Spreadsheet.IWorkbook

        Public Sub New(SetModelID As Integer)

            ModelID = SetModelID
            WB = ExcelModels(ModelID)

        End Sub
        'Public Sub SynchroniseTransactionalDB(ModelID As Integer)

        '    Dim FileInstance As FileInstanceInterface = ExcelModels(ModelID).InstanceInterface
        '    Dim TransactionalDB As TransactionalDBInterface = ExcelModels(ModelID).TransactionalDBInterface
        '    If TransactionalDB Is Nothing Then Exit Sub
        '    Dim SyncData As Object = FileInstance.GetTransactionalDBSyncData(ModelID)
        '    If SyncData Is Nothing Then Exit Sub
        '    TransactionalDB.SynchroniseTransactionalDB(ModelID, SyncData)

        'End Sub

        Public Sub SynchroniseOFA()

        End Sub

    End Class

End Namespace
