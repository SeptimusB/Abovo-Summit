﻿Imports Abovo.AbovoAppCls
Imports Abovo.FileManager
Imports Abovo.WorkbookManager
Imports Abovo.WSSecurity
Imports DevExpress.CodeParser
Imports DevExpress.Pdf.Native.BouncyCastle.Asn1.X509
Imports DevExpress.Spreadsheet
Imports DevExpress.XtraRichEdit.Layout

Namespace Abovo
    Public Class WorkbookManager

#Region "Worksheet manipulation"

        Public Shared Function DoesNRExist(ModelID As Integer, RangeName As String) As Boolean

            Dim WB As DevExpress.Spreadsheet.IWorkbook = ExcelModels(ModelID).WB
            Dim TargetdefinedRange As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(RangeName)
            If TargetdefinedRange Is Nothing Then
                Return False
            Else
                Return True
            End If

        End Function
        Public Shared Function GetRangeRows(ModelID As Integer, RangeName As String) As Integer

            Dim WB As DevExpress.Spreadsheet.IWorkbook = ExcelModels(ModelID).WB

            Dim TargetdefinedRange As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(RangeName)
            Dim CRTargetRange As DevExpress.Spreadsheet.CellRange = TargetdefinedRange.Range

            Return CRTargetRange.RowCount

        End Function

        Public Shared Function GetRangeColumns(ModelID As Integer, RangeName As String) As Integer

            Dim WB As DevExpress.Spreadsheet.IWorkbook = ExcelModels(ModelID).WB

            Dim TargetdefinedRange As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(RangeName)
            Dim CRTargetRange As DevExpress.Spreadsheet.CellRange = TargetdefinedRange.Range

            Return CRTargetRange.ColumnCount

        End Function

        Public Shared Function SetRangeRowsToSize(ModelID As Integer, RangeName As String, SetSize As Integer, Optional ByVal IgnoreFinalRow As Boolean = False) As AbovoTransaction

            Dim ThisTrans As New AbovoTransaction
            Dim CurrentSize As Integer = GetRangeRows(ModelID, RangeName)
            If CurrentSize = SetSize Then
                ThisTrans.BError = False
                ThisTrans.StringReturn = "No change needed"
                Return ThisTrans
            End If
            If CurrentSize < SetSize Then
                ThisTrans = InsertRows(ModelID, RangeName, SetSize - CurrentSize, , IgnoreFinalRow)
            Else
                ThisTrans = DeleteRows(ModelID, RangeName, CurrentSize - SetSize, , IgnoreFinalRow)
            End If
            Return ThisTrans

        End Function

        Public Shared Function SetRangeColsToSize(ModelID As Integer, RangeName As String, SetSize As Integer) As AbovoTransaction

            Dim ThisTrans As New AbovoTransaction
            Dim CurrentSize As Integer = GetRangeRows(ModelID, RangeName)
            If CurrentSize = SetSize Then
                ThisTrans.BError = False
                ThisTrans.StringReturn = "No change needed"
                Return ThisTrans
            End If
            If CurrentSize < SetSize Then
                ThisTrans = InsertColumns(ModelID, RangeName, SetSize - CurrentSize)
            Else
                ThisTrans = DeleteColumns(ModelID, RangeName, CurrentSize - SetSize)
            End If
            Return ThisTrans

        End Function

        Public Shared Function InsertRows(ModelID As Integer, TargetNamedRange As String, Optional ByVal RowsToAdd As Integer = 1, Optional ByVal JustFormats As Boolean = False, Optional ByVal IgnoreFinalRow As Boolean = False) As AbovoTransaction

            'On Error GoTo Err_Handler_A

            ExcelModels(ModelID).ModelSpreadsheetControl.Options.Clipboard.AllowFormulasInBiff8 = True

            Dim WB As DevExpress.Spreadsheet.IWorkbook = ExcelModels(ModelID).WB

            Dim ThisTrans As New AbovoTransaction

            Dim TargetDefinedName As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(TargetNamedRange)
            Dim bIsGlobal As Boolean = TargetDefinedName.IsGlobal

            Dim WSTarget As DevExpress.Spreadsheet.Worksheet = TargetDefinedName.Range.Worksheet

            Dim PriorBottomRow As Integer = TargetDefinedName.Range.BottomRowIndex

            Try

                WB.BeginUpdate()

                If IgnoreFinalRow Then PriorBottomRow -= 1

                Dim TempWidthRange As DevExpress.Spreadsheet.CellRange = WSTarget.GetUsedRange
                Dim UsedSheetWidth As Integer = TempWidthRange.ColumnCount

                Dim Reprotect As Boolean = False

                If WSTarget.IsProtected Then

                    Reprotect = True
                    UNProtectWS(ModelID, WSTarget.Name)

                End If

                'Insert entire row/s above the current bottom row
                WSTarget.Rows.Insert(PriorBottomRow + 1, RowsToAdd)

                'Exit Function

                'Copy the row before the prior bottom row to the prior bottom row
                WSTarget.Rows(PriorBottomRow + 1).CopyFrom(WSTarget.Rows(PriorBottomRow), PasteSpecial.All)

                'Clear any values in the now populated bottom row + 1 and copy them from the new position of the prior bottom row

                Dim CellExamine As DevExpress.Spreadsheet.Cell

                For Col = 0 To UsedSheetWidth - 1

                    CellExamine = WSTarget.Cells(PriorBottomRow + 1, Col)

                    If Not CellExamine.Protection.Locked Then

                        If Not CellExamine.HasFormula Then

                            CellExamine.ClearContents

                        End If

                    End If

                Next Col

                'copy everything from corrected bottom row + 1 to the new cells

                For i = 1 To RowsToAdd Step 1

                    WSTarget.Rows(PriorBottomRow + i).CopyFrom(WSTarget.Rows(PriorBottomRow + 1), PasteSpecial.Formulas)
                    WSTarget.Rows(PriorBottomRow + i).CopyFrom(WSTarget.Rows(PriorBottomRow + 1), PasteSpecial.Formats)

                Next

                If Reprotect Then ProtectWS(ModelID, WSTarget.Name)

                ThisTrans.BError = False
                Dim TempRange As DevExpress.Spreadsheet.CellRange = WSTarget.Range.FromLTRB(TargetDefinedName.Range.LeftColumnIndex, TargetDefinedName.Range.TopRowIndex, TargetDefinedName.Range.RightColumnIndex, TargetDefinedName.Range.BottomRowIndex + RowsToAdd)

                Dim TargetAddress As String = WSTarget.Name & "!" & TempRange.GetReferenceA1()

                TargetDefinedName = Nothing

                If bIsGlobal Then

                    WB.DefinedNames.GetDefinedName(TargetNamedRange).Range = TempRange

                Else

                    WSTarget.DefinedNames.GetDefinedName(TargetNamedRange).Range = TempRange

                End If

                ExcelModels(ModelID).ModelSpreadsheetControl.Options.Clipboard.AllowFormulasInBiff8 = False

            Catch ex As Exception

            Finally

                WB.EndUpdate()

                TargetDefinedName = Nothing
                WSTarget = Nothing
                WB = Nothing

            End Try

            Return ThisTrans

            Exit Function

            ThisTrans.BError = True
            ThisTrans.StringReturn = Err.Description

            Return ThisTrans

        End Function
        Public Shared Function InsertColumns(ModelID As Integer, TargetNamedRange As String, Optional ByVal ColsToAdd As Integer = 1, Optional ByVal JustFormats As Boolean = False, Optional ByVal IgnoreFinalCol As Boolean = False) As AbovoTransaction

            ExcelModels(ModelID).ModelSpreadsheetControl.Options.Clipboard.AllowFormulasInBiff8 = True

            Dim WB As DevExpress.Spreadsheet.IWorkbook = ExcelModels(ModelID).WB

            Dim ThisTrans As New AbovoTransaction

            Dim TargetDefinedName As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(TargetNamedRange)

            Dim WSTarget As DevExpress.Spreadsheet.Worksheet = TargetDefinedName.Range.Worksheet

            Dim PriorRightCol As Integer = TargetDefinedName.Range.RightColumnIndex


            Try

                WB.BeginUpdate()

                If IgnoreFinalCol Then PriorRightCol -= 1

                Dim TempWidthRange As DevExpress.Spreadsheet.CellRange = WSTarget.GetUsedRange
                Dim UsedSheetDepth As Integer = TempWidthRange.RowCount

                Dim Reprotect As Boolean = False

                If WSTarget.IsProtected Then

                    Reprotect = True
                    UNProtectWS(ModelID, WSTarget.Name)

                End If

                'Insert entire col/s above the current bottom row
                WSTarget.Columns.Insert(PriorRightCol, ColsToAdd)

                'Exit Function

                'Copy the row before the prior bottom row to the prior bottom row
                WSTarget.Columns(PriorRightCol).CopyFrom(WSTarget.Columns(PriorRightCol - 1), PasteSpecial.All)

                'Clear any values in the now populated prior bottom row and copy them from the new position of the prior bottom row

                Dim CellExamine As DevExpress.Spreadsheet.Cell

                For h = 0 To UsedSheetDepth - 1

                    CellExamine = WSTarget.Cells(h, PriorRightCol)

                    If Not CellExamine.Protection.Locked Then

                        If Not CellExamine.HasFormula Then
                            CellExamine.Value = WSTarget.Cells(PriorRightCol + ColsToAdd, h).Value
                            CellExamine.ClearContents
                        End If

                    End If

                Next h

                'copy everything from corrected prior bottom row to the new cells

                For i = 1 To ColsToAdd Step 1

                    WSTarget.Columns(PriorRightCol + i).CopyFrom(WSTarget.Columns(PriorRightCol), PasteSpecial.All)

                Next

                If Reprotect Then ProtectWS(ModelID, WSTarget.Name)

                ThisTrans.BError = False

                ExcelModels(ModelID).ModelSpreadsheetControl.Options.Clipboard.AllowFormulasInBiff8 = False

            Catch ex As Exception

            Finally

                WB.EndUpdate()

                TargetDefinedName = Nothing
                WSTarget = Nothing
                WB = Nothing

            End Try

            Return ThisTrans

            Exit Function

            ThisTrans.BError = True
            ThisTrans.StringReturn = Err.Description

            Return ThisTrans

        End Function
        Public Shared Function DeleteRows(ModelID As Integer, TargetNamedRange As String, Optional ByVal RowsToDelete As Integer = 1, Optional ByVal JustFormats As Boolean = False, Optional ByVal IgnoreFinalRow As Boolean = False) As AbovoTransaction

            'On Error GoTo Err_Handler_A

            Dim WB As DevExpress.Spreadsheet.IWorkbook = ExcelModels(ModelID).WB
            Dim ThisTrans As New AbovoTransaction
            Dim TargetDefinedName As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(TargetNamedRange)
            Dim WSTarget As DevExpress.Spreadsheet.Worksheet = TargetDefinedName.Range.Worksheet
            Dim OutMessage As String = ""
            Dim CurrentRangeRows As Integer = TargetDefinedName.Range.RowCount
            Dim PriorBottomRow As Integer = TargetDefinedName.Range.BottomRowIndex

            If IgnoreFinalRow Then

                PriorBottomRow -= 1
                CurrentRangeRows -= 1

            End If

            Dim ActualRowsToDelete As Integer = RowsToDelete

            If CurrentRangeRows - RowsToDelete <= 3 Then
                ActualRowsToDelete = CurrentRangeRows - 3
                OutMessage = "Maximum rows deletable is " & ActualRowsToDelete & ". "
            End If

            If ActualRowsToDelete <= 0 Then
                OutMessage += " No rows can be deleted."
                ThisTrans.BError = True
                ThisTrans.StringReturn = OutMessage
                Return ThisTrans
            End If

            UNProtectWS(ModelID, WSTarget.Name)

            WSTarget.Rows.Remove(PriorBottomRow - ActualRowsToDelete, ActualRowsToDelete)

            ProtectWS(ModelID, WSTarget.Name)

            TargetDefinedName = Nothing
            WSTarget = Nothing
            WB = Nothing

            ThisTrans.BError = False
            ThisTrans.StringReturn = OutMessage

            ExcelModels(ModelID).ModelSpreadsheetControl.Options.Clipboard.AllowFormulasInBiff8 = False

            Return ThisTrans

            Exit Function

Err_Handler_A:

            ThisTrans.BError = True
            ThisTrans.StringReturn = Err.Description

            Return ThisTrans

        End Function

        Public Shared Function DeleteColumns(ModelID As Integer, TargetNamedRange As String, Optional ByVal ColsToDelete As Integer = 1, Optional ByVal JustFormats As Boolean = False) As AbovoTransaction

            'On Error GoTo Err_Handler_A

            Dim WB As DevExpress.Spreadsheet.IWorkbook = ExcelModels(ModelID).WB
            Dim ThisTrans As New AbovoTransaction
            Dim TargetDefinedName As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(TargetNamedRange)
            Dim WSTarget As DevExpress.Spreadsheet.Worksheet = TargetDefinedName.Range.Worksheet
            Dim OutMessage As String = ""
            Dim CurrentRangeCols As Integer = TargetDefinedName.Range.ColumnCount
            Dim PriorRightCol As Integer = TargetDefinedName.Range.RightColumnIndex

            Dim ActualColsToDelete As Integer = ColsToDelete

            If CurrentRangeCols - ColsToDelete <= 3 Then
                ActualColsToDelete = CurrentRangeCols - 3
                OutMessage = "Maximum columns deletable is " & ActualColsToDelete & ". "
            End If

            If ActualColsToDelete < 0 Then
                OutMessage += " No columns can be deleted."
                ThisTrans.BError = True
                ThisTrans.StringReturn = OutMessage
                Return ThisTrans
            End If

            UNProtectWS(ModelID, WSTarget.Name)

            WSTarget.Columns.Remove(PriorRightCol - ActualColsToDelete, ActualColsToDelete)

            ProtectWS(ModelID, WSTarget.Name)

            TargetDefinedName = Nothing
            WSTarget = Nothing
            WB = Nothing

            ThisTrans.BError = False
            ThisTrans.StringReturn = OutMessage

            ExcelModels(ModelID).ModelSpreadsheetControl.Options.Clipboard.AllowFormulasInBiff8 = False

            Return ThisTrans

            Exit Function

Err_Handler_A:

            ThisTrans.BError = True
            ThisTrans.StringReturn = Err.Description

            Return ThisTrans

        End Function


        Public Shared Function DevExpressInsertRows(ModelID As Integer, TargetNamedRange As String, Optional ByVal RowsToAdd As Integer = 1, Optional ByVal JustFormats As Boolean = False, Optional ByVal IgnoreFinalRow As Boolean = False) As AbovoTransaction

            'On Error GoTo Err_Handler_A

            Dim WB As DevExpress.Spreadsheet.IWorkbook = ExcelModels(ModelID).WB
            Dim ThisTrans As New AbovoTransaction
            Dim TargetDefinedName As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(TargetNamedRange)
            Dim bIsGlobal As Boolean = TargetDefinedName.IsGlobal
            Dim CRTarget As DevExpress.Spreadsheet.CellRange

            Dim WSTarget As DevExpress.Spreadsheet.Worksheet = TargetDefinedName.Range.Worksheet

            Dim PriorBottomRow As Integer = TargetDefinedName.Range.BottomRowIndex

            If IgnoreFinalRow Then PriorBottomRow -= 1

            Dim Lref As Integer = TargetDefinedName.Range.LeftColumnIndex
            Dim Rref As Integer = TargetDefinedName.Range.RightColumnIndex
            Dim Tref As Integer = TargetDefinedName.Range.TopRowIndex
            Dim Bref As Integer = TargetDefinedName.Range.BottomRowIndex

            TargetDefinedName = Nothing
            'TargetDefinedName.RefersTo = Nothing

            Debug.Print("Inserting at row " & PriorBottomRow & " in range " & TargetNamedRange)

            WSTarget.Rows.Insert(PriorBottomRow + 1, RowsToAdd)

            CRTarget = WSTarget.Range.FromLTRB(Lref, Tref, Rref, Bref + RowsToAdd)

            If bIsGlobal Then

                WB.DefinedNames.GetDefinedName(TargetNamedRange).Range = CRTarget

            Else

                WSTarget.DefinedNames.GetDefinedName(TargetNamedRange).Range = CRTarget

            End If

            Dim CRCopySource As CellRange = WSTarget.Range.FromLTRB(Lref, PriorBottomRow, Rref, PriorBottomRow)

            Dim DestRow As CellRange

            For i = 1 To RowsToAdd

                DestRow = WSTarget.Range.FromLTRB(CRTarget.LeftColumnIndex, PriorBottomRow + i, CRTarget.RightColumnIndex, PriorBottomRow + i)

                If JustFormats Then
                    DestRow.CopyFrom(CRCopySource, PasteSpecial.Formats, True)
                Else
                    DestRow.CopyFrom(CRCopySource, PasteSpecial.Values Or PasteSpecial.Formats, True)
                End If

            Next

            DestRow = Nothing
            CRCopySource = Nothing
            CRTarget = Nothing
            WSTarget = Nothing
            WB = Nothing

            ThisTrans.BError = False

            Return ThisTrans

            Exit Function

Err_Handler_A:

            ThisTrans.BError = True
            ThisTrans.StringReturn = Err.Description

            Return ThisTrans

        End Function
        Public Shared Function InsertColumn(WB As DevExpress.Spreadsheet.Workbook, TargetNamedRange As String, Optional ByVal ColssToAdd As Integer = 1) As AbovoTransaction

            On Error GoTo Err_Handler_A

            Dim ThisTrans As New AbovoTransaction

            Dim TargetdefinedRange As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(TargetNamedRange)

            Dim CRTargetRange As DevExpress.Spreadsheet.CellRange = TargetdefinedRange.Range
            Dim CRTargetWorksheet As DevExpress.Spreadsheet.Worksheet = CRTargetRange.Worksheet
            Dim IntRangeRows As Integer = CRTargetRange.RowCount
            Dim IntRangeCols As Integer = CRTargetRange.ColumnCount

            On Error Resume Next

            CRTargetWorksheet.Unprotect(UnlockPassword)

            On Error GoTo Err_Handler_A

            WB.BeginUpdate()

            Dim IntRightCol As Integer = CRTargetRange.RightColumnIndex

            CRTargetWorksheet.Columns.Insert(IntRightCol)
            CRTargetWorksheet.Columns(IntRightCol).CopyFrom(CRTargetWorksheet.Columns(IntRightCol + 1), PasteSpecial.Formulas)
            CRTargetWorksheet.Columns(IntRightCol).CopyFrom(CRTargetWorksheet.Columns(IntRightCol + 1), PasteSpecial.Formats)
            CRTargetWorksheet.Columns(IntRightCol + 1).ClearContents
            CRTargetRange.Resize(IntRangeRows, IntRangeCols + 1)

            On Error Resume Next

            CRTargetWorksheet.Protect(UnlockPassword, WorksheetProtectionPermissions.Default)

            On Error GoTo Err_Handler_A

            If ColssToAdd > 1 Then

            End If

            WB.EndUpdate()

            ThisTrans.BError = False

            Return ThisTrans

            Exit Function

Err_Handler_A:

            ThisTrans.BError = True
            ThisTrans.StringReturn = Err.Description

            Return ThisTrans

        End Function
#End Region
        Public Shared Sub CopyRowToRangeBottom(ModelID As Integer, RangeName As String)

            Dim WB As IWorkbook = ExcelModels(ModelID).WB

            Dim TargetDefinedRange As DevExpress.Spreadsheet.DefinedName = WB.DefinedNames.GetDefinedName(RangeName)
            Dim CRTargetRange As CellRange
            Dim CRTargetWorksheet As DevExpress.Spreadsheet.Worksheet
            Dim topRow As CellRange

RestartFrom:

            WB = ExcelModels(ModelID).WB
            TargetDefinedRange = WB.DefinedNames.GetDefinedName(RangeName)
            CRTargetRange = TargetDefinedRange.Range
            CRTargetWorksheet = CRTargetRange.Worksheet

            topRow = CRTargetWorksheet.Range.FromLTRB(CRTargetRange.LeftColumnIndex, CRTargetRange.TopRowIndex, CRTargetRange.RightColumnIndex, CRTargetRange.TopRowIndex)

            ' Find Empty Row
            Dim bottomRow As CellRange = Nothing

            For i As Integer = CRTargetRange.TopRowIndex To CRTargetRange.TopRowIndex + CRTargetRange.RowCount

                Dim rowCell As CellRange = CRTargetWorksheet.Range.FromLTRB(CRTargetRange.LeftColumnIndex, i, CRTargetRange.RightColumnIndex, i)

                If rowCell.ToArray().All(Function(cell) cell.Value.IsEmpty) Then

                    bottomRow = rowCell
                    Exit For

                End If

            Next

            If (bottomRow Is Nothing) Then

                ' Extend
                topRow = Nothing
                WB = Nothing
                TargetDefinedRange = Nothing
                CRTargetRange = Nothing
                CRTargetWorksheet = Nothing

                InsertRows(ModelID, RangeName, 1)

                GoTo RestartFrom

                'bottomRow = CRTargetWorksheet.Range.FromLTRB(CRTargetRange.LeftColumnIndex, CRTargetRange.BottomRowIndex + 1, CRTargetRange.RightColumnIndex, CRTargetRange.BottomRowIndex + 1)

                'CRTargetWorksheet.DefinedNames.GetDefinedName(RangeName).Range = CRTargetRange.Resize(CRTargetRange.RowCount + 1, CRTargetRange.ColumnCount)

            End If

            ' Copy
            bottomRow.CopyFrom(topRow, PasteSpecial.Values, True)

        End Sub

    End Class

End Namespace