﻿Imports System.Drawing
Imports System.Windows.Forms

Imports DevExpress.Utils
Imports DevExpress.Utils.Drawing
Imports DevExpress.XtraEditors.Controls
Imports DevExpress.XtraEditors.Drawing

Imports DevExpress.XtraVerticalGrid
Imports DevExpress.XtraVerticalGrid.Events
Imports DevExpress.XtraVerticalGrid.Rows

Imports Abovo.GeneralFunctions


Namespace Abovo

    Public Class VGridCategoryButtonExtender

        Private view As VGridControl
        Private ActiveCategoryRow As CategoryRow

        Private customButtonPainter As SkinEditorButtonPainter
        Private args As EditorButtonObjectInfoArgs

        Private buttonSize As Size = New Size(28, 28)

        Private MyOwner As DataInterfaceTemplate
        Private SectionID As Integer
        Private MyDesc As String

        Private _ActionToken As ActionToken

        'Unlike the XtraGrid BandTag implementation, keep the
        'button state here. This avoids requiring anything extra
        'in the CategoryRow.Tag object.
        Private ButtonObjectState As ObjectState = ObjectState.Normal

        'The actual button bounds are calculated when the category
        'row is drawn. Mouse handlers can then use exactly the same
        'rectangle.
        Private CurrentButtonRect As Rectangle = Rectangle.Empty


        Public Sub New(ByVal view As VGridControl,
                       ByVal Category As CategoryRow,
                       ByVal Opener As DataInterfaceTemplate,
                       ByVal DefaultAction As String,
                       ByVal SetSectionID As Integer,
                       ByVal SetTitle As String,
                       ByVal ActTok As ActionToken)

            Me.view = view
            Me.ActiveCategoryRow = Category

            MyOwner = Opener
            SectionID = SetSectionID
            MyDesc = SetTitle
            _ActionToken = ActTok

        End Sub


        Public Sub AddCustomButton()

            CreateButtonPainter()
            CreateButtonInfoArgs()
            SubscribeToEvents()

            view.InvalidateRow(ActiveCategoryRow)

        End Sub


        Private Sub CreateButtonInfoArgs()

            Dim btn As New EditorButton(ButtonPredefines.Plus)

            btn.ToolTip = "Add Rows"
            btn.ToolTipAnchor = ToolTipAnchor.Cursor
            btn.IsLeft = True

            args = New EditorButtonObjectInfoArgs(
                btn,
                New DevExpress.Utils.AppearanceObject()
            )

        End Sub


        Private Sub CreateButtonPainter()

            customButtonPainter =
                New SkinEditorButtonPainter(
                    DevExpress.LookAndFeel.UserLookAndFeel.Default.ActiveLookAndFeel
                )

        End Sub


        Private Sub SubscribeToEvents()

            AddHandler view.CustomDrawRowHeaderCell,
                       AddressOf OnCustomDrawRowHeaderCell

            AddHandler view.MouseDown,
                       AddressOf OnMouseDown

            AddHandler view.MouseUp,
                       AddressOf OnMouseUp

            AddHandler view.MouseMove,
                       AddressOf OnMouseMove

            AddHandler view.MouseLeave,
                       AddressOf OnMouseLeave

        End Sub


        Private Sub OnMouseDown(ByVal sender As Object,
                                ByVal e As MouseEventArgs)

            If e.Button <> MouseButtons.Left Then Return

            Dim hitInfo As VGridHitInfo = view.CalcHitInfo(e.Location)

            If hitInfo.Row Is Nothing Then Return
            If hitInfo.Row IsNot ActiveCategoryRow Then Return

            If IsButtonRect(e.Location) Then

                SetButtonState(ObjectState.Pressed)

                DXMouseEventArgs.GetMouseArgs(e).Handled = True

            End If

        End Sub


        Private Sub OnMouseUp(ByVal sender As Object,
                              ByVal e As MouseEventArgs)

            If e.Button <> MouseButtons.Left Then Return

            Dim hitInfo As VGridHitInfo = view.CalcHitInfo(e.Location)

            If hitInfo.Row Is Nothing Then

                SetButtonState(ObjectState.Normal)
                Return

            End If

            If hitInfo.Row IsNot ActiveCategoryRow Then

                SetButtonState(ObjectState.Normal)
                Return

            End If

            If IsButtonRect(e.Location) Then

                SetButtonState(ObjectState.Hot)

                MyOwner.RunAction(_ActionToken)

                DXMouseEventArgs.GetMouseArgs(e).Handled = True

            Else

                SetButtonState(ObjectState.Normal)

            End If

        End Sub


        Private Sub OnMouseMove(ByVal sender As Object,
                                ByVal e As MouseEventArgs)

            Dim hitInfo As VGridHitInfo = view.CalcHitInfo(e.Location)

            If hitInfo.Row IsNot Nothing AndAlso
               hitInfo.Row Is ActiveCategoryRow AndAlso
               IsButtonRect(e.Location) Then

                If ButtonObjectState <> ObjectState.Pressed Then
                    SetButtonState(ObjectState.Hot)
                End If

            Else

                If ButtonObjectState <> ObjectState.Normal Then
                    SetButtonState(ObjectState.Normal)
                End If

            End If

        End Sub


        Private Sub OnMouseLeave(ByVal sender As Object,
                                 ByVal e As EventArgs)

            If ButtonObjectState <> ObjectState.Normal Then
                SetButtonState(ObjectState.Normal)
            End If

        End Sub


        Private Sub SetButtonState(ByVal state As ObjectState)

            If ButtonObjectState = state Then Return

            ButtonObjectState = state

            view.InvalidateRow(ActiveCategoryRow)

        End Sub


        Private Function IsButtonRect(ByVal point As Point) As Boolean

            If CurrentButtonRect.IsEmpty Then Return False

            Return CurrentButtonRect.Contains(point)

        End Function


        Private Function CalcButtonRect(ByVal HeaderBounds As Rectangle) As Rectangle

            Dim ButtonTop As Integer =
                HeaderBounds.Top +
                ((HeaderBounds.Height - buttonSize.Height) \ 2)

            Dim ButtonLeft As Integer =
                HeaderBounds.Right -
                buttonSize.Width -
                4

            Return New Rectangle(
                ButtonLeft,
                ButtonTop,
                buttonSize.Width,
                buttonSize.Height
            )

        End Function


        Private Sub OnCustomDrawRowHeaderCell(
            ByVal sender As Object,
            ByVal e As CustomDrawRowHeaderCellEventArgs)

            If e.Row Is Nothing Then Return

            If e.Row IsNot ActiveCategoryRow Then Return

            '
            'IMPORTANT:
            '
            'Let DevExpress draw the category row normally first.
            '
            'This preserves things particular to a VGrid category,
            'including its expand/collapse presentation, skin,
            'background, etc.
            '
            e.Painter.DrawObject(e.ObjectArgs)

            CurrentButtonRect = CalcButtonRect(e.Bounds)

            DrawCategoryHighlight(e)

            DrawCustomButton(e)

            e.Handled = True

        End Sub


        Private Sub DrawCustomButton(
            ByVal e As CustomDrawRowHeaderCellEventArgs)

            SetUpButtonInfoArgs(e)

            customButtonPainter.DrawObject(args)

        End Sub


        Private Sub SetUpButtonInfoArgs(
            ByVal e As CustomDrawRowHeaderCellEventArgs)

            args.Cache = e.Cache
            args.Bounds = CurrentButtonRect
            args.State = ButtonObjectState

        End Sub


        Private Sub DrawCategoryHighlight(
            ByVal e As CustomDrawRowHeaderCellEventArgs)

            '
            'Equivalent in principle to the highlight line used by
            'BandButtonExtender.
            '
            'I've deliberately kept AbovoBlue here rather than
            'introducing another Tag dependency.
            '
            Dim CellPadding As Integer = 28

            Using pen As New Pen(AbovoBlue, 4)

                e.Cache.DrawLine(
                    pen,
                    New Point(e.Bounds.Left + CellPadding,
                              e.Bounds.Bottom - 1),
                    New Point(e.Bounds.Right,
                              e.Bounds.Bottom - 1)
                )

            End Using

        End Sub


        Private Sub UnsubscribeFromEvents()

            RemoveHandler view.CustomDrawRowHeaderCell,
                          AddressOf OnCustomDrawRowHeaderCell

            RemoveHandler view.MouseDown,
                          AddressOf OnMouseDown

            RemoveHandler view.MouseUp,
                          AddressOf OnMouseUp

            RemoveHandler view.MouseMove,
                          AddressOf OnMouseMove

            RemoveHandler view.MouseLeave,
                          AddressOf OnMouseLeave

        End Sub


        Public Sub RemoveCustomButton()

            UnsubscribeFromEvents()

            CurrentButtonRect = Rectangle.Empty

            If view IsNot Nothing AndAlso
               ActiveCategoryRow IsNot Nothing Then

                view.InvalidateRow(ActiveCategoryRow)

            End If

        End Sub

    End Class

End Namespace