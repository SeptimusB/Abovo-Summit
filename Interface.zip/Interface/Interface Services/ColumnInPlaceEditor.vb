﻿
Imports Abovo.GeneralFunctions
Imports Abovo.AbovoExtendedDEControls
Imports DevExpress.Utils
Imports DevExpress.XtraEditors
Imports Abovo.DataObject

Imports DevExpress.XtraEditors.Repository
Imports DevExpress.XtraEditors.ViewInfo
Imports DevExpress.XtraGrid.Columns
Imports DevExpress.XtraGrid.Drawing
Imports DevExpress.XtraGrid.Views.BandedGrid
Imports DevExpress.XtraGrid.Views.BandedGrid.ViewInfo
Imports DevExpress.XtraGrid.Views.Base
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraGrid.Views.Grid.ViewInfo
Imports Microsoft.VisualBasic

Namespace Abovo
	Public Class ColumnInplaceEditorHelper

		Private _Item As RepositoryItem
		Private _Column As BandedGridColumn
		Private bgview As GridView
		Public LinkedComboBoxEdit As AbovoDEHeaderComboBox
		Public LinkedDateEdit As AbovoDEHeaderDateBox
		Public Tag As Object

		Public Sub New(ByVal column As BandedGridColumn, ByVal inplaceEditor As RepositoryItem)
			_Column = column
			_Item = inplaceEditor
			bgview = TryCast(column.View, BandedGridView)
			'_ActiveEditor = New BaseEdit
			'_ActiveEditor.ForeColor = Color.Red
			AddHandler bgview.CustomDrawColumnHeader, AddressOf view_CustomDrawColumnHeader
			AddHandler bgview.MouseDown, AddressOf view_MouseDown
			AddHandler bgview.Layout, AddressOf view_Layout
		End Sub

		Private Sub view_Layout(ByVal sender As Object, ByVal e As EventArgs)
			CloseEditor()
		End Sub

		Private _EditValue As Object
		Public Property EditValue() As Object
			Get
				Return _EditValue
			End Get
			Set(ByVal value As Object)
				_EditValue = value
			End Set
		End Property

		Private _ActiveEditor As BaseEdit
		Public Property ActiveEditor() As BaseEdit
			Get
				Return _ActiveEditor
			End Get
			Set(ByVal value As BaseEdit)
				_ActiveEditor = value
			End Set
		End Property

        Private Sub view_CustomDrawColumnHeader(ByVal sender As Object, ByVal e As ColumnHeaderCustomDrawEventArgs)
			If e.Column Is Nothing Then Return
			Dim ColTag As DataColumnTag = TryCast(e.Column.Tag, DataColumnTag)
			If ColTag IsNot Nothing AndAlso Not ColTag.HasIncolumnEditor Then
                e.Handled = True
                Return
            End If

			Debug.Print("Inplace editor - custom draw - " & e.Column.AbsoluteIndex)
			If e.Column.AbsoluteIndex = 0 Then Return
			If e.Column Is _Column Then
				'e.Appearance.Options.UseBackColor = True
				'e.Appearance.BackColor = AbovoComboBGC
				'e.Info.Caption = String.Empty
				'Dim br As New SolidBrush(AbovoComboBGC)
				'e.Cache.FillRectangle(br, e.Bounds)
				'e.DefaultDraw()
				e.Painter.DrawObject(e.Info)

				DrawEditorHelper.DrawColumnInplaceEditor(e, _Item, EditValue, GetRightIndent())
				Debug.Print("Inplace editor - finished custom draw - " & e.Column.AbsoluteIndex)
				e.Handled = True

			End If
		End Sub

		Public Function GetRightIndent() As Integer
			If _Column.OptionsColumn.AllowSort <> DevExpress.Utils.DefaultBoolean.False OrElse _Column.OptionsFilter.AllowFilter Then
				Return 25
			Else
				Return 0
			End If
		End Function
		Private Sub view_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs)
			CloseEditor()
			Dim editorBounds As Rectangle
			If ClickInEditor(e, editorBounds) Then
				ShowEditor(editorBounds)
				DXMouseEventArgs.GetMouseArgs(e).Handled = True
			End If
		End Sub
		Private Function ClickInEditor(ByVal e As MouseEventArgs, <System.Runtime.InteropServices.Out()> ByRef editorBounds As Rectangle) As Boolean
			editorBounds = Rectangle.Empty
			Dim vi As BandedGridViewInfo = TryCast(bgview.GetViewInfo(), BandedGridViewInfo)
			Dim columnInfo As GridColumnInfoArgs = CalcColumnHitInfo(e.Location, vi.ColumnsInfo)

			If columnInfo IsNot Nothing AndAlso columnInfo.Column Is _Column Then
				editorBounds = DrawEditorHelper.GetEditorBounds(columnInfo.Bounds, GetRightIndent())
				Return editorBounds.Contains(e.Location)
			End If
			Return False

		End Function

		Protected Overridable Function CalcColumnHitInfo(ByVal pt As Point, ByVal cols As GridColumnsInfo) As GridColumnInfoArgs
			For Each ci As GridColumnInfoArgs In cols
				If (Not ci.Bounds.IsEmpty) AndAlso IntInRange(pt.X, ci.Bounds.Left, ci.Bounds.Right) Then
					If ci.Type = GridColumnInfoType.EmptyColumn Then
						Continue For
					End If
					Return ci
				End If
			Next ci
			Return Nothing
		End Function

		Protected Function IntInRange(ByVal x As Integer, ByVal left As Integer, ByVal right As Integer) As Boolean
			If right < left Then
				Dim temp As Integer = left
				left = right
				right = temp
			End If
			Return (x >= left AndAlso x < right)
		End Function

		Private Sub ShowEditor(ByVal bounds As Rectangle)
			ActiveEditor = _Item.CreateEditor()
			ActiveEditor.Properties.LockEvents()
			ActiveEditor.Properties.Appearance.Options.UseBackColor = True
			ActiveEditor.Properties.Appearance.BackColor = _Item.Appearance.BackColor
			ActiveEditor.Properties.Appearance.Options.UseForeColor = True
			ActiveEditor.Properties.Appearance.ForeColor = _Item.Appearance.ForeColor
			ActiveEditor.Tag = Tag
			ActiveEditor.Parent = bgview.GridControl
			ActiveEditor.Properties.Assign(_Item)
			ActiveEditor.Properties.AutoHeight = True
			ActiveEditor.Location = bounds.Location
			ActiveEditor.Size = bounds.Size
			ActiveEditor.CreateControl()
			ActiveEditor.EditValue = EditValue
			ActiveEditor.SendMouse(ActiveEditor.PointToClient(Control.MousePosition), Control.MouseButtons)
			ActiveEditor.Properties.UnLockEvents()
		End Sub

		Private Sub CloseEditor()
			If ActiveEditor IsNot Nothing Then
				EditValue = ActiveEditor.EditValue
				ActiveEditor.Dispose()
				ActiveEditor = Nothing
			End If
		End Sub
		Private Sub editor_Leave(ByVal sender As Object, ByVal e As EventArgs)
			CloseEditor()
		End Sub
	End Class



End Namespace