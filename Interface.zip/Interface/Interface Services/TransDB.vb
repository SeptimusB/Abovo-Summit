﻿Imports DevExpress.Spreadsheet
Imports Abovo.WorkbookManager
Imports Abovo.FileManager
Namespace Abovo

    Public Class TransDBManager
        Public ModelID As Integer
        Public Sub New(SetModelID As Integer)

            ModelID = SetModelID

        End Sub
        Public Shared Sub CheckTransDBActions(ModelID As Integer, TargRng As String)

            Dim TargCount As Integer = GetRangeRows(ModelID, TargRng)

            TargCount += 1 ' to include footer row


            If DoesNRExist(ModelID, "TransCopy_" & TargRng) Then

                If GetRangeRows(ModelID, "TransCopy_" & TargRng) <> TargCount Then

                    If Not ExcelModels(ModelID).ExpendAnalyser Is Nothing Then

                        ExcelModels(ModelID).ExpendAnalyser.DisconectRDS()

                    End If

                    SetRangeRowsToSize(ModelID, "TransCopy_" & TargRng, TargCount, True)

                    If DoesNRExist(ModelID, "TransCopy_" & TargRng & "_01") Then

                        SetRangeRowsToSize(ModelID, "TransCopy_" & TargRng & "_01", TargCount, True)

                    End If

                    If DoesNRExist(ModelID, "TransCopy_" & TargRng & "_02") Then

                        SetRangeRowsToSize(ModelID, "TransCopy_" & TargRng & "_02", TargCount, True)

                        If DoesNRExist(ModelID, "TransCopy_" & TargRng & "_02") Then SetRangeRowsToSize(ModelID, "TransCopy_" & TargRng & "_02", TargCount, True)
                        If DoesNRExist(ModelID, "TransCopy_" & TargRng & "_03") Then SetRangeRowsToSize(ModelID, "TransCopy_" & TargRng & "_03", TargCount, True)
                        If DoesNRExist(ModelID, "TransCopy_" & TargRng & "_04") Then SetRangeRowsToSize(ModelID, "TransCopy_" & TargRng & "_04", TargCount, True)
                        If DoesNRExist(ModelID, "TransCopy_" & TargRng & "_05") Then SetRangeRowsToSize(ModelID, "TransCopy_" & TargRng & "_05", TargCount, True)
                        If DoesNRExist(ModelID, "TransCopy_" & TargRng & "_06") Then SetRangeRowsToSize(ModelID, "TransCopy_" & TargRng & "_06", TargCount, True)

                    End If

                    If Not ExcelModels(ModelID).ExpendAnalyser Is Nothing Then

                        ExcelModels(ModelID).ExpendAnalyser.ReconnectRDS()

                    End If

                End If


            End If



        End Sub

    End Class

End Namespace