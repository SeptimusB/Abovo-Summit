# Abovo Summit architecture

## Startup and model service graph

1. `Application.vb` creates `FormMainScreen`.
2. The main form selects or creates a workbook and calls `FileManager.OpenModel`.
3. `FileManager.ExcelModel` owns the DevExpress Spreadsheet document and per-model services.
4. `WorkbookContractValidator` checks `Global Assumptions`, its `A8` marker, and `Transactional DB` before normal services initialise.
5. Post-load setup creates calculation, change/history, migration, Transactional DB, structure, data, presentation, event, dependency, and interface services.
6. `StructureManager` deserialises inline XML, an explicit XML path, or deployed `Structure.xml` into the UI/data contract.
7. `ProcessAsAbovoBP` reads workbook metadata and creates the file interface.
8. Calculation runs manually, chain-based, and multithreaded through `EngineManagement` and `CustomCalcEngine`.

## Interface pipeline

```text
Structure.xml
  -> StructureManager object graph
  -> PresentationManager.DataPresentation
  -> DataManager.GetISEDataStructure
  -> DataCellRange / DataRows / DataColumns / CellDataPoints
  -> DataInterfaceTemplate
  -> DevExpress XtraGrid, BandedGridView, or VGridControl
```

`DataManager` resolves worksheets and named ranges, applies modes including `MergeAcross`, `MergeDownAndPivot`, and `SingleCell`, constructs `DataColumnTag` metadata, and preserves `SourceSheet`/`SourceAddress` for write-back. `PresentationManager` assigns datasets through stable `ControlSourceIndex` values. `DataInterfaceTemplate` builds controls, editors, painting, structural buttons, lazy tabs, refresh, paste, and specialised renderers.

## Edit pipeline

```text
grid/VGrid edit or paste
  -> locate DataCellRange + CellDataPoint
  -> ModelChangeManager.ProcessChange
  -> workbook update + change log + dirty state
  -> rules/calculation
  -> targeted data/interface refresh
```

For XtraGrid, map displayed rows to datasource rows with `GetFocusedDataSourceRowIndex`/`GetDataSourceRowIndex`, not row handles, after sorting or filtering. VGrid is rotated: `RecordIndex` maps to dataset row and the VGrid row maps to dataset column.

## Structural-change pipeline

```text
UI Add/Delete Records
  -> semantic rule ID or named-range-to-rule resolution
  -> WorkbookStructureRuleManager
  -> WorkbookManager operations across linked sheets
  -> finish structural transaction
  -> TransactionalDBSynchroniser once
  -> InterfaceDependencyManager notifications
  -> targeted atomic rebuild + rules/recalculation
```

Displayed and physical axes may differ. Rules own the physical layout, anchors, template copying, minimum record counts, and linked worksheets. `RebuildSelectedSectionAtomically` suppresses intermediate painting with `WM_SETREDRAW`, brackets DevExpress updates, reapplies layout, and repaints once. Off-screen dirty tabs remain lazy-loaded.

## Transactional DB contract

`Transactional DB` contains linked copies of named ranges used for aggregate/drill-down analysis. `TransactionalDBSynchroniser` mirrors workbook `Summit_Compatibility` behaviour across Development, Joint Ventures, Capital Grant, Repairs, CapEx, Funding, Intercompany Funding, Housing Components, and OFA. All 89 referenced `TransCopy_...` ranges were represented when migration was implemented.

Synchronisation is worksheet-aware, resizes only misaligned mirrors, preserves footer/template rows, and uses a re-entrancy guard. Never synchronise midway through a linked-sheet operation. `TransactionDBMaterialiser` and `WorkbookMigrationManager` maintain compatibility/mirror metadata; the baseline workbook is schema 10.

## Joint Venture specialisation

Generic `MergeDownAndPivot` does not fit Joint Venture assumptions. `DataInterfaceTemplate.BuildJointVentureExcelStyleVGrid` interprets existing workbook named ranges directly for `CSID = 21` while preserving source addresses and the normal change path.

- `NRCI` on `IC_JointVenture_01` adds actual JV workbook columns/VGrid records.
- `NRRI` on `IR_JointVenture_01a` to `_04a` adds event/year rows inside the four expandable categories.
- `Rep_OrdinalYears` supplies `1`–`40` year strings.
- A blank JV Name locks lower cells; locked/rule-controlled cells are Lavender and non-editable.
- Description/Year are presentation columns; synthetic `From year` text must not write to the workbook.

## Baseline workbook

`Library\TestFileMigrated.xlsb` has 297 worksheets, 1,772 defined names, about 579,605 formulas, no external workbook links/connections, and migration schema 10. It includes migration metadata, template cache, Transactional DB, and Development Identified mirror sheets. Embedded VBA was not fully audited by the read-only workbook analysis.
