# Abovo Summit coding conventions and guardrails

## General approach

- Preserve public interfaces and workbook behaviour unless explicitly changing them.
- Make one logical change at a time in high-risk core classes; build and smoke-test after each stage.
- Prefer targeted corrections over broad rewrites of `DataManager`, `DataInterfaceTemplate`, `WorkbookMigrationManager`, or `Structure.xml`.
- Keep generated/Designer files paired with forms and edit Designer output only when required.
- Treat `Archive\Legacy Repository Files` as read-only history.

## VB.NET compatibility

- This is a classic .NET Framework 4.8 project with legacy style and no project-wide `Option Strict On` convention.
- Match surrounding style; use explicit `ByVal`, `Nothing` guards, and established naming where practical.
- Keep comma-separated properties contiguous inside multiline `With { ... }` initialisers; place explanatory comments outside them. Comments or disruptive line breaks previously caused cascades of VB syntax errors.
- Confirm compiler support before adding language/runtime features.
- Reuse DevExpress 25.2.4 APIs and existing repository items.

## Workbook and data rules

- Cache workbook, worksheet, defined-name, and range objects in hot paths.
- Preserve `SourceSheet`, `SourceAddress`, `DataColumnTag`, validation, rule, editor, and format metadata.
- Use `ModelChangeManager.ProcessChange`/`ProcessChangeByNRAddressing` for real edits. Direct assignment is only for controlled internal maintenance already designed that way.
- Batch multi-cell edits and run rules/calculation/refresh once after the batch.
- Blank paste meaning—clear or skip—remains an unresolved product decision.
- Distinguish display row handles from datasource indices after sorting/filtering.
- In VGrid, records are dataset rows and VGrid rows are dataset columns.

## Structure.xml rules

- `IElement.DataSource` is a zero-based collection index.
- Keep the first `CellRangeDataSource` resolvable when a routine uses it to establish dimensions; do not lead with an unresolvable calculated source.
- `TipText` belongs under `DataFieldDefinition`, where `DataManager` reads it.
- Keep named-range and repository references valid against the baseline workbook.
- Do not bulk-remove duplicate legacy fields without understanding deserialisation/runtime effects and testing affected interfaces.
- Workings interfaces default to read-only unless explicitly justified.

## Structural operations

- Express intent as Add/Delete Records; rules decide rows versus columns.
- Rules define anchors, axis, linked worksheets, template-copy mode, minimum count, and Transactional DB sync key.
- Finish linked changes before synchronisation, dependency invalidation, recalculation, or UI rebuild.
- Preserve sentinel/template/footer rows and honour `SkipLastRecords` and record-count adjustments.
- Signed counts are positive for add and negative for delete only where the current footer contract expects that model.

## DevExpress UI conventions

- Give XtraGrid and VGrid separate handlers where their event/coordinate models differ.
- For custom-painted clickable controls, use the exact painted rectangle as the primary hover/click target; complex band hit testing can disagree.
- Subscribe/unsubscribe handlers symmetrically and dispose repositories/helpers with the host control.
- Apply final font before best-fit/layout calculations. Enforce DPI/font-aware VGrid width minima without shrinking wider calculated widths.
