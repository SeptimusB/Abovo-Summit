# Conversation inclusion and provenance report

## Raw export processed

- Source: `D:\Temp\wzdbeb\conversations.json`.
- Size: 11,099,218 bytes.
- Export conversations scanned: 23.
- Processed locally on 18 August 2026.
- Unrelated personal conversation content is not reproduced in this pack.

## Included canonical coding conversations

| Conversation | ID | Export dates (UTC) | Main material used |
|---|---|---|---|
| Joint Venture VGrid Setup | `6a82e950-d048-83eb-bebe-7a6f51a75fb0` | 17 Aug 2026 10:58–15:47 | JV redesign/V10 baseline; Assumptions and note mapping; Presentation/DataManager optimisation plan; handoff context |
| Revisit TransactionDB optimisation | `6a8038d2-98bc-83eb-9714-353bc50863d2` | 15 Aug 2026 10:01–17 Aug 15:48 | Transactional DB compatibility; structural rules; linked changes; lazy/atomic refresh; Fix 49–56 family; active header/footer path; `NRRIbyCOL` |
| Editor Assignment Update | `6a7dbc94-0d88-83ed-a9e5-8cf0eb6bb218` | 13 Aug 2026 12:47–15 Aug 11:22 | VGrid editor/drawing parity; dynamic repository refresh; custom Ctrl+V; rotated paste; change-manager integration; unresolved paste semantics |

## Duplicate and exclusions

- `Revisit TransactionDB optimisation` (`6a832d71-e354-83eb-9b9d-706a5aef2aaf`) is a near-duplicate/projectless copy and was not treated as an additional canonical source.
- `Abovo-Summit Logo Design` (`67d874d8-2d80-800e-8c69-3b596568ce93`) was excluded because it is branding/image work, not Summit coding or architecture.
- All other personal, relationship, travel, translation, naming, humour, writing, pricing, and unrelated conversations were excluded.

## Repository cross-check

Current filenames were checked against `C:\Repos\Abovo Summit`, including the solution/project, `Structure.xml`, schema-10 baseline workbook and audit, code audit, and primary data/presentation/change/structure/Transactional DB classes. Repository files were read only during consolidation. The current `git status` shows modifications to `DataInterfaceTemplate.vb` and `StressTest.vb`; those pre-existing changes were not touched.

## Result

The earlier source limitation is resolved for this export: all 23 records in the supplied JSON were scanned. The seven Markdown artifacts are a concise, coding-only handoff, not a full transcript or a replacement for live repository inspection.
