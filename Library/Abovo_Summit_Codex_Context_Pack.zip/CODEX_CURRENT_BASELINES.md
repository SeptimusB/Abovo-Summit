# Abovo Summit current baselines

## Live repository baselines

Treat these live files as authoritative over earlier generated artifacts:

| Purpose | Current filename |
|---|---|
| Solution | `Abovo Business Suite.sln` |
| VB project | `Abovo Business Suite.vbproj` |
| XML UI/data contract | `Structure.xml` |
| Baseline workbook | `Library\TestFileMigrated.xlsb` |
| Workbook analysis | `Library\TestFileMigrated.analysis.md` |
| Code audit | `APPLICATION_CODE_PASS.md` |
| Main interface renderer | `Interface\User Interface\DataInterfaceTemplate.vb` |
| Data construction | `Services\DataService\DataManager.vb` |
| Presentation construction | `Services\Presentation\PresentationManager.vb` |
| Structure model | `Services\StructureCreation\StructureManager.vb` |
| Change manager | `Services\DataService\ChangeManager.vb` |
| Workbook operations | `Services\WorkbookManager.vb` |
| Structural rules | `Services\WorkbookStructureRuleManager.vb` |
| Transactional DB synchroniser | `Services\TransactionalDB\TransactionalDBSynchroniser.vb` |
| Transactional DB materialiser | `TransactionDBMaterialiser.vb` |
| Migrations | `WorkbookMigrationManager.vb` |
| Shared control formatting | `Interface\Interface Services\ObjectFormatter.vb` |
| Repository editors | `Interface\Interface Services\RepositaryItems.vb` |
| Active combined painter | `Interface\Interface Services\CombinedColumnBandButton&HeaderFooterDrawer.vb` |
| Stress Test interface | `Interface\StressTest\StressTest.vb` |
| Multivariable Dashboard audit | `Library\Multivariable_Dashboard_Technical_Audit.md` |

## Historical accepted artifacts

These names matter when reading conversation history but are superseded by live files:

- `DataInterfaceTemplate_JointVenture_ExcelStyle_V10.txt` — last explicitly accepted JV DIT artifact; behaviour is integrated into live `DataInterfaceTemplate.vb`.
- `Structure_JointVenture_ExcelStyle.txt` — JV XML redesign artifact; superseded by live `Structure.xml`.
- `Structure_Assumptions_KeyPoint_PreNotes_20260817.txt` — requested pre-note key-point snapshot.
- `Structure_Assumptions_Corrected_PreNotes.txt` — accepted Assumptions baseline after fixing Real Dvpt Rent and relocating 20 `TipText` elements; later superseded by mapped-note Structure and live `Structure.xml`.
- `TestFileMigrated(1).xlsb` and `Structure(20260817-111911).xml` — upload names; repository baselines use normalised names.
- Uploaded `DataManager(1).vb`, `PresentationManager(1).vb`, `ChangeManager(1).vb`, and `WorkbookManager(1).vb` were conversation snapshots, not current filenames.

## Accepted behavioural baseline

- Assumptions had 44 child structures with contiguous CSID values 0–43 at audit time.
- Economic Assumptions → Real Dvpt Rent uses datasource index 0.
- Misplaced Assumptions `TipText` nodes were moved into `DataFieldDefinition`.
- The approximate note mapping added 331 non-overwriting tips from 195 workbook notes: 294 high-confidence and 37 good. Whitespace was collapsed and the XLSB was unchanged.
- Joint Venture is a dedicated Excel-style VGrid with separate add-column and add-line semantics.
- Structural Fixes through Fix 56 were smoke-tested: signed structural footers, `NRRIbyCOL`, active combined header/footer click handling, responsive widths, lazy/atomic tab rebuilds, and targeted refresh.

## Current Stress Test baseline

- Development version 6.67 is the current presentation baseline.
- Tab #4 is a native DevExpress reproduction of the workbook's
  `Multivariable Dashboard`; it does not host or expose a spreadsheet control.
- Dashboard selectors use the workbook's linked cells through
  `ModelChangeManager`. Matrix values, breach indicators, chart, debt outputs,
  and result cards reload from the calculated workbook ranges.
- The year, sort metric/order, and selected covenant use a `SpinEdit`, two
  `RadioGroup` controls, and a `ToggleSwitch` rather than worksheet-style form
  controls.
- Debug and Release builds passed on 19 August 2026 with zero warnings and
  zero errors.
