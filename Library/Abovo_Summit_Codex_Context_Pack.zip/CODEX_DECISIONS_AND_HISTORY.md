# Abovo Summit key decisions and history

## Workbook-first architecture

The XLSB remains a complete standalone model. Summit is a presentation, editing, calculation, migration, and analysis layer. Named ranges and workbook geometry remain core contracts, and presented data retains worksheet/address origin.

## Transactional DB synchronisation

Workbook `Summit_Compatibility` VBA behaviour was mirrored in `TransactionalDBSynchroniser`. The synchroniser covers all 89 referenced `TransCopy_...` ranges across Development, JV, Capital Grant, Repairs, CapEx, Funding, Intercompany Funding, Components, and OFA. It resolves compatibility rules by worksheet, touches only misaligned mirrors, and runs once after a linked structural operation.

This led to semantic structural rules: UI controls request Add/Delete Records and `WorkbookStructureRuleManager` decides the physical axis, linked sheets, anchors, template copies, minimum counts, and Transactional DB follow-up. OFA was converted first, followed by CapEx, Capital Grant, Repairs, Components, Funding, Development, Journal, and other high-confidence families. `NRRIbyCOL` was restored because repeated-column UI actions may require underlying row insertion.

## Lazy refresh and atomic rebuilds

Interface dependencies now support targeted dirty/rebuild behaviour. Off-screen tabs remain unloaded and rebuild lazily. Visible section recreation is atomic using `WM_SETREDRAW` and DevExpress update brackets, avoiding visible collapse/reflow.

## Active header/footer button path

Early fixes targeted legacy classes that were not active on Rent interfaces. The live object was traced to `CombinedColumnBandButton_HeaderFooterDrawer`. The accepted fix caches exact painted header, band, and footer button rectangles and uses them for mouse-up hit detection, with DevExpress hit testing as fallback. The `NRRIbyCOL` action branch was restored in `RunAction`.

## Joint Venture redesign

Generic `MergeDownAndPivot` showed the wrong visual shape. A dedicated Excel-style JV VGrid for `CSID = 21` reads existing named ranges without restructuring the workbook.

- JV Name and Opening Balance lead the grid.
- Investments, Share of Surplus/Deficit, Cash Repayments, and Interest Rate remain expandable.
- Add JV uses `NRCI`/`IC_JointVenture_01` to add workbook columns/VGrid records.
- Category additions use `NRRI`/`IR_JointVenture_01a`–`04a` to add workbook rows.
- Year editors use `Rep_OrdinalYears` (`1`–`40`).
- Writes use the normal change-manager path.
- Blank JV names lock lower cells; locked/rule-controlled cells are Lavender.
- The last accepted generated DIT was `DataInterfaceTemplate_JointVenture_ExcelStyle_V10.txt`; behaviour is now live.
- One-pixel footer-border remnants are accepted as cosmetic unless client feedback changes priority.

## Assumptions/Structure audit

The Assumptions audit found 44 child structures with contiguous IDs, valid worksheet/name references, and 58 valid repository references. Real Dvpt Rent was corrected from datasource index 1 to 0. Twenty misplaced `TipText` elements moved from `CellRangeDataSource` into `DataFieldDefinition`.

An approximate workbook-note mapping added 331 missing `TipText` values from 195 notes—294 high-confidence and 37 good—without overwriting tips or changing the XLSB. Mapping respects datasource orientation. Ambiguous duplicate metadata in Development and Capital interfaces was deliberately retained pending focused testing.

## VGrid/XtraGrid parity and paste

VGrid gained dedicated painting, validation, showing/shown-editor, per-cell repository, dynamic repository refresh, and disposal paths. Shared formatting gives captions bold Abovo-blue styling. DPI/font-aware width minima prevent Funding records being crushed by best-fit.

Ctrl+V is intercepted before default DevExpress paste. Clipboard text becomes a rectangular tab/newline matrix. XtraGrid maps normally; VGrid rotates it. Each accepted value resolves a `CellDataPoint` and calls `PushDSData`/the change manager, with rules/calculation/refresh deferred until the batch ends. Blank semantics and block-level undo remain future decisions.

## Performance work

`PresentationManager` was the low-risk first stage: preallocate section/element/dataset capacity, centralise dataset construction, and reuse stable slots during section redefinition. The remaining hotspot is `DataManager.GetISEDataStructure`, with repeated array growth, named-range lookup, validation scans, and mixed responsibilities. The intended design is discover final shape, allocate rows/cells once, then populate.

## Repository cleanup

On 18 August 2026, a code pass reviewed 150 compiled files (about 62,600 lines), removed project-source `SystemLog`/`Debug.Print` usage, moved 62 excluded/superseded files into `Archive\Legacy Repository Files`, and recorded a Debug build with zero errors and warnings. Operational user-facing errors and the in-memory application log were retained.
