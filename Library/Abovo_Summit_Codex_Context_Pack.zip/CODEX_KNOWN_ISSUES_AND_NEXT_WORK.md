# Abovo Summit known issues and next work

## Immediate engineering priorities

1. Client-test Stress Test Tabs #4-#6 version 6.68 against populated scenario
   data. Confirm the native year selector, sort controls, five-metric matrix,
   custom target/breach indicators, selected covenant chart, debt outputs and
   result cards against the workbook. Also confirm comparison line separation,
   extrema, shared series visibility and all five independent date windows.
   Do not expose a spreadsheet control or duplicate workbook calculation rules
   in the interface.
2. Optimise `DataManager.GetISEDataStructure`: measure by datasource mode, cache workbook/name objects, discover final columns first, allocate `DataColumns` and every row's `DataCells` once, then populate. Avoid cell-by-cell `ReDim Preserve`.
3. Optimise validation lookup: `DataValidationsSet.CheckValidation` may scan list-validation ranges for every cell. Add a safe cache/index only after measurement.
4. Build Workings interfaces: audit the Workings `GroupStructure` against the workbook first. Default presentations to read-only unless explicitly enabled.
5. Add contract tests: open/save baseline XLSB, Structure deserialisation, schema detection, named-range resizing, linked structural operations, Transactional DB materialisation/synchronisation, and targeted interface dataset construction.

## Open product/behaviour decisions

- Blank paste cell: clear the workbook target or skip it?
- Paste history: one block-level change-log/undo transaction or individual cell entries?
- Paste conversion: final rules for dates, percentages, currencies, repositories, validation failures, selection-sized targets, and all-or-nothing behaviour.
- JV one-pixel footer artefacts remain accepted unless client feedback justifies more paint-order work.

## Known technical risks

- `FormMainScreen.NewBP` is intentionally blank; Create New needs redesign. `Templates\DefaultBPTemplate.xlsb` is referenced but absent/unused.
- `ApplyPendingMigrations` now runs for both Debug and Release full-model loads. Migration failures abort opening the model; imported source workbooks do not use the full-model migration path. The current baseline is schema 10.
- Active source still contains approximately 26 `On Error Resume Next` statements and 91 empty `Catch` blocks. Replace incrementally with narrow handling and explicit transaction failures.
- There is no automated test project.
- `DataInterfaceTemplate`, `DataManager`, and `WorkbookMigrationManager` are large mixed-responsibility classes. Extract focused services when extending behaviour.
- `ChangeLogManager.DataChange` contains a dormant `NotImplementedException`; implement or remove it before adding a call path.
- Worksheet protection values are application data, not a security boundary.
- Embedded VBA remains an operational compatibility layer. Revalidate corresponding VBA and native paths whenever workbook-facing behavior changes.

## XML cleanup backlog

- Conflicting/duplicate `DataFieldDefinition` metadata remains in Development Details, Development Dets. Multi-Year, Capital Grant, Capital Expenditure, and smaller legacy cases.
- Duplicate `BandID`, `PositID`, `RowsExpandModel`, and spelling/caption remnants remain.
- Assumptions & tenure inputs is not currently an Assumptions child structure; reassess during the Workings audit rather than assuming omission.
- Do not clean in bulk. Confirm deserialised/runtime behaviour and smoke-test each interface family.

## Verification baseline

Version 6.68 passed Debug and Release builds on 19 August 2026 with zero
warnings and zero errors. Interactive confirmation against a populated client
dashboard remains a client/runtime task.
