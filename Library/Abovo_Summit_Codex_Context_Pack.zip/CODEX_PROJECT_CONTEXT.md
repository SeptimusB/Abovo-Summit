# Abovo Summit — Codex project context

Last consolidated: 18 August 2026.

## What this project is

Abovo Summit is a VB.NET WinForms application for opening, validating, presenting, editing, calculating, migrating, and analysing a large standalone financial-model workbook. The workbook remains authoritative: Summit presents workbook ranges through DevExpress grids/VGrids, writes edits through the change manager, and maintains the workbook's structural and Transactional DB contracts.

The live repository is `C:\Repos\Abovo Summit`. This pack is a reference mirror; change the live repository only when a task explicitly requests it.

## Technology baseline

- Visual Basic .NET, classic MSBuild project, .NET Framework 4.8, WinForms.
- Solution: `Abovo Business Suite.sln`.
- Project: `Abovo Business Suite.vbproj`; output assembly `Abovo-summit`.
- DevExpress 25.2.4, including Spreadsheet, XtraGrid, VerticalGrid, Editors, Navigation, Printing, and Charts.
- Primary workbook: standalone `.xlsb`; normal behaviour must not depend on Excel automation.

## Authoritative current files

- UI/data contract: `Structure.xml`.
- Baseline workbook: `Library\TestFileMigrated.xlsb`.
- Workbook audit: `Library\TestFileMigrated.analysis.md`.
- Main UI renderer/controller: `Interface\User Interface\DataInterfaceTemplate.vb`.
- Presentation construction: `Services\Presentation\PresentationManager.vb`.
- Workbook-range dataset construction: `Services\DataService\DataManager.vb`.
- Change/write path: `Services\DataService\ChangeManager.vb`.
- Structure model/deserialisation: `Services\StructureCreation\StructureManager.vb` and `XMLParser.vb`.
- Structural rules: `Services\WorkbookStructureRuleManager.vb` and `Services\WorkbookManager.vb`.
- Transactional DB compatibility: `Services\TransactionalDB\TransactionalDBSynchroniser.vb`, `TransactionDBMaterialiser.vb`, and `WorkbookMigrationManager.vb`.

## Non-negotiable behavioural invariants

1. Keep the XLSB usable as a standalone workbook; do not replace workbook formulas or structure with app-only state.
2. Route real cell edits through `ModelChangeManager.ProcessChange` (or the named-range equivalent) so logging, dirty state, calculation, validation, and refresh remain coherent.
3. Treat structural actions as semantic add/delete-record operations. The physical workbook axis may be rows or columns, especially for `MergeDownAndPivot` data.
4. Complete linked-sheet structural changes before Transactional DB synchronisation, interface invalidation, or recalculation.
5. Preserve source worksheet/address mappings for every presented cell.
6. Keep `Structure.xml`, named ranges, repositories, `DataManager`, `PresentationManager`, and `DataInterfaceTemplate` aligned; an XML datasource index is an array index, not merely a descriptive ID.
7. Preserve stable `DataSets` indices during section rebuilds because controls retain `ControlSourceIndex` references.
8. Do not silently normalise ambiguous legacy XML. Fix confirmed contract errors separately and smoke-test affected interfaces.
9. Work narrowly in the live project. `Archive\Legacy Repository Files` is historical reference, not active source.

## Current state

The application has a clean recorded .NET 4.8/DevExpress 25.2.4 baseline and a schema-10 audited workbook. The Assumptions XML has been substantially audited, Joint Venture uses a dedicated Excel-style VGrid, structural operations have moved toward declarative workbook rules, Transactional DB mirrors synchronise after linked changes, and grid/VGrid paste routes through the change manager. The next principal engineering work is `DataManager` allocation/validation optimisation, followed by read-only Workings interfaces and stronger automated contract tests.

The present working tree must be rebuilt before being declared green because `DataInterfaceTemplate.vb` and `StressTest.vb` are modified.
